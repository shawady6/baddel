Baddel - Arabic <-> English keyboard fixer

Install (Chrome / Edge / Brave / Opera):
1. Extract this ZIP somewhere permanent.
2. Open chrome://extensions (edge://extensions) and turn on Developer mode.
3. Click "Load unpacked" and choose the "baddel" folder.

Use: select text typed in the wrong language and press Ctrl+Shift+X
(change the shortcut from the extension's settings page).

Website:  https://shawady6.github.io/baddel/
Source:   https://github.com/shawady6/baddel
License:  MIT
